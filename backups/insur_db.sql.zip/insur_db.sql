-- phpMyAdmin SQL Dump
-- version 3.2.3
-- http://www.phpmyadmin.net
--
-- Host: localhost
-- Generation Time: Sep 12, 2012 at 08:37 PM
-- Server version: 5.1.40
-- PHP Version: 5.3.3

SET SQL_MODE="NO_AUTO_VALUE_ON_ZERO";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;

--
-- Database: `insur_db`
--

-- --------------------------------------------------------

--
-- Table structure for table `insur_article_categories`
--

CREATE TABLE IF NOT EXISTS `insur_article_categories` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `category_name` varchar(45) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 AUTO_INCREMENT=1 ;

--
-- Dumping data for table `insur_article_categories`
--


-- --------------------------------------------------------

--
-- Table structure for table `insur_article_content`
--

CREATE TABLE IF NOT EXISTS `insur_article_content` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `content` longtext,
  `created` datetime DEFAULT NULL COMMENT 'дата/время создания',
  `status` int(11) DEFAULT NULL COMMENT 'по умолчанию - опубликована, доступна. -1 - заблокирована',
  `insur_coworkers_id` int(11) NOT NULL,
  PRIMARY KEY (`id`,`insur_coworkers_id`),
  KEY `fk_insur_article_content_insur_coworkers1` (`insur_coworkers_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='													' AUTO_INCREMENT=1 ;

--
-- Dumping data for table `insur_article_content`
--


-- --------------------------------------------------------

--
-- Table structure for table `insur_article_matrix`
--

CREATE TABLE IF NOT EXISTS `insur_article_matrix` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `article_category_id` int(11) NOT NULL,
  `article_id` int(11) NOT NULL,
  PRIMARY KEY (`id`,`article_category_id`,`article_id`),
  KEY `fk_insur_article_matrix_insur_article_categories1` (`article_category_id`),
  KEY `fk_insur_article_matrix_insur_article_content1` (`article_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 AUTO_INCREMENT=1 ;

--
-- Dumping data for table `insur_article_matrix`
--


-- --------------------------------------------------------

--
-- Table structure for table `insur_coworkers`
--

CREATE TABLE IF NOT EXISTS `insur_coworkers` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `id_role` int(11) NOT NULL COMMENT 'id должности',
  `name_middlename_surname` text COMMENT 'Фамилия, имя, отчество',
  `insur_workers_roles_id` int(11) NOT NULL,
  PRIMARY KEY (`id`,`insur_workers_roles_id`),
  KEY `fk_insur_coworkers_insur_workers_roles` (`insur_workers_roles_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 AUTO_INCREMENT=1 ;

--
-- Dumping data for table `insur_coworkers`
--


-- --------------------------------------------------------

--
-- Table structure for table `insur_workers_roles`
--

CREATE TABLE IF NOT EXISTS `insur_workers_roles` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `role_name` varchar(45) DEFAULT NULL COMMENT 'должность',
  `description` varchar(45) DEFAULT NULL COMMENT 'Описание должности',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 AUTO_INCREMENT=1 ;

--
-- Dumping data for table `insur_workers_roles`
--


--
-- Constraints for dumped tables
--

--
-- Constraints for table `insur_article_content`
--
ALTER TABLE `insur_article_content`
  ADD CONSTRAINT `fk_insur_article_content_insur_coworkers1` FOREIGN KEY (`insur_coworkers_id`) REFERENCES `insur_coworkers` (`id`) ON DELETE NO ACTION ON UPDATE NO ACTION;

--
-- Constraints for table `insur_article_matrix`
--
ALTER TABLE `insur_article_matrix`
  ADD CONSTRAINT `fk_insur_article_matrix_insur_article_categories1` FOREIGN KEY (`article_category_id`) REFERENCES `insur_article_categories` (`id`) ON DELETE NO ACTION ON UPDATE NO ACTION,
  ADD CONSTRAINT `fk_insur_article_matrix_insur_article_content1` FOREIGN KEY (`article_id`) REFERENCES `insur_article_content` (`id`) ON DELETE NO ACTION ON UPDATE NO ACTION;

--
-- Constraints for table `insur_coworkers`
--
ALTER TABLE `insur_coworkers`
  ADD CONSTRAINT `fk_insur_coworkers_insur_workers_roles` FOREIGN KEY (`insur_workers_roles_id`) REFERENCES `insur_workers_roles` (`id`) ON DELETE NO ACTION ON UPDATE NO ACTION;
